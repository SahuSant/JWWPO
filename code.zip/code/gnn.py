import networkx as nx
import matplotlib.pyplot as plt
from keras.layers import Input, Dense, Concatenate
from keras.models import Model
from keras.optimizers import Adam
from keras.layers import Layer
import numpy as np
import tensorflow as tf
import JWWPO
from skimage.metrics import structural_similarity
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from keras.optimizers import Adam as opt
tf.config.run_functions_eagerly(True)
import cv2
def visual_similarity(inp_img,G):
    img2 = cv2.imread('1.png', 0)
    inp_img = cv2.cvtColor(inp_img, cv2.COLOR_BGR2GRAY)
    img2 = cv2.resize(img2,(inp_img.shape))
    score, diff = structural_similarity(inp_img.astype(int), img2, full=True)
    return score

def attack(G):

    att = []
    for i, edge in enumerate(G.edges()):
        no_attack = [(u, v) for u,v in G.edges]
        if edge not in no_attack:
            data = {}


            H = G.copy()

            # attack an edge
            H.remove_edges_from(ebunch=[edge])

            n = len(G.nodes)
            retain_node_ids = [9, 3]
            H.add_edges_from([(u, v) for u in retain_node_ids for v in (n+1, n+2)])

            # remove nodes with degree < 2
            H = nx.k_core(H, k=2)
            H.remove_nodes_from([n + 1, n + 2])


            # delete connected nodes and edges
            diff_nodes = set(G.nodes()).difference(H.nodes())
            diff_edges = {e for e in G.edges() for n in diff_nodes if n in e}



            data['diff_nodes'] = list(diff_nodes)
            data['diff_edges'] = list(diff_edges)
            data['edge'] = edge
            att.append(True)
        else:
            att.append(False)
        ASR = len(G.edges) / att.count(False)
        if True in att:

            return True ,ASR
        else:
            return False, ASR


class GraphConvolution(Layer):
    def __init__(self, output_dim, **kwargs):
        self.output_dim = output_dim
        super(GraphConvolution, self).__init__(**kwargs)

    def build(self, input_shape):
        self.kernel = self.add_weight(name='kernel',
                                      shape=(input_shape[1], self.output_dim),
                                      initializer='glorot_uniform',
                                      trainable=True)
        super(GraphConvolution, self).build(input_shape)

    def call(self, x):
        output = tf.matmul(x, self.kernel)
        return output

    def compute_output_shape(self, input_shape):
        return (input_shape[0], self.output_dim)
def classify(data,target,G,inp,ACC,ASR,VS):


    X_train, Y_train = data,target
    X_train = X_train.reshape(1, -1)
    Y_train = Y_train.reshape(-1, 1)
    n_features = X_train.shape[1]
    n_hidden = 8
    n_classes = len(np.unique(Y_train))
    X_input = Input(shape=(n_features,))
    # Define the graph convolutional layer
    graph_conv = GraphConvolution(output_dim=n_hidden)(X_input)
    # Define the output layer
    output_layer = Dense(units=n_classes, activation='softmax')(graph_conv)
    # Define the model
    model = Model(inputs=X_input, outputs=output_layer)
    # Compile the model

    model.compile(optimizer=opt(lr = JWWPO.algm()), loss='categorical_crossentropy', metrics=['accuracy'])
    # Train the model


    model.fit(X_train, Y_train, batch_size=32, epochs=1,verbose=0)

    predict = model.predict(X_train)
    ATTACK , asr = attack(G)
    #
    if ATTACK:
        return ATTACK
    else:
        vs = visual_similarity(inp, G)
        acc = accuracy_score(target, predict)
        ACC.append(acc)
        VS.append(vs)
        ASR.append(asr)






