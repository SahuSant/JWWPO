import random
from torchvision import transforms, datasets
import powerlaw
import networkx as nx
import pickle

from scipy.spatial.distance import cdist

import numpy as np

import dgl
import torch
import time
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib
import os

from Main import gnn

os.chdir('../') # go to root folder of the project
print(os.getcwd())


def sigma(dists, kth=8):
    # Get k-nearest neighbors for each node
    knns = np.partition(dists, kth, axis=-1)[:, kth::-1]

    # Compute sigma and reshape
    sigma = knns.sum(axis=1).reshape((knns.shape[0], 1)) / kth
    return sigma + 1e-8  # adding epsilon to avoid zero value of sigma


def compute_adjacency_matrix_images(coord, feat, use_feat=False, kth=8):
    coord = coord.reshape(-1, 2)
    # Compute coordinate distance
    c_dist = cdist(coord, coord)

    if use_feat:
        # Compute feature distance
        f_dist = cdist(feat, feat)
        # Compute adjacency
        A = np.exp(- (c_dist / sigma(c_dist)) ** 2 - (f_dist / sigma(f_dist)) ** 2)
    else:
        A = np.exp(- (c_dist / sigma(c_dist)) ** 2)

    # Convert to symmetric matrix
    A = 0.5 * (A + A.T)
    # A = 0.5 * A * A.T
    A[np.diag_indices_from(A)] = 0
    return A


def compute_edges_list(A, kth=8 + 1):
    # Get k-similar neighbor indices for each node
    if 1 == 1:
        num_nodes = A.shape[0]
        new_kth = num_nodes - kth
        knns = np.argpartition(A, new_kth - 1, axis=-1)[:, new_kth:-1]
        knns_d = np.partition(A, new_kth - 1, axis=-1)[:, new_kth:-1]
    else:
        knns = np.argpartition(A, kth, axis=-1)[:, kth::-1]
        knns_d = np.partition(A, kth, axis=-1)[:, kth::-1]
    return knns, knns_d


class MNISTSuperPix(torch.utils.data.Dataset):
    def __init__(self,
                 data_dir,
                 split,
                 use_mean_px=True,
                 use_coord=True,
                 use_feat_for_graph_construct=False, ):

        self.split = split
        self.is_test = split.lower() in ['test', 'val']
        with open(os.path.join(data_dir, 'mnist_75sp_%s.pkl' % split), 'rb') as f:
            self.labels, self.sp_data = pickle.load(f)

        self.use_mean_px = use_mean_px
        self.use_feat_for_graph = use_feat_for_graph_construct
        self.use_coord = use_coord
        self.n_samples = len(self.labels)
        self.img_size = 28

    def precompute_graph_images(self):
        print('precompute all data for the %s set...' % self.split.upper())
        self.Adj_matrices, self.node_features, self.edges_lists = [], [], []
        for index, sample in enumerate(self.sp_data):
            mean_px, coord = sample[:2]
            coord = coord / self.img_size
            A = compute_adjacency_matrix_images(coord, mean_px, use_feat=self.use_feat_for_graph)
            edges_list, _ = compute_edges_list(A)
            N_nodes = A.shape[0]

            x = None
            if self.use_mean_px:
                x = mean_px.reshape(N_nodes, -1)
            if self.use_coord:
                coord = coord.reshape(N_nodes, 2)
                if self.use_mean_px:
                    x = np.concatenate((x, coord), axis=1)
                else:
                    x = coord
            if x is None:
                x = np.ones(N_nodes, 1)  # dummy features

            self.node_features.append(x)
            self.Adj_matrices.append(A)
            self.edges_lists.append(edges_list)

    def __len__(self):
        return self.n_samples

    def __getitem__(self, index):
        g = dgl.DGLGraph()
        g.add_nodes(self.node_features[index].shape[0])
        g.ndata['feat'] = torch.Tensor(self.node_features[index])

        for src, dsts in enumerate(self.edges_lists[index]):
            g.add_edges(src, dsts[dsts != src])

        return g, self.labels[index]
def get_features(plt, sp_data, adj_matrix, label, feat_coord, with_edges):
    from scipy.spatial.distance import pdist, squareform
    Y = squareform(pdist(sp_data[1], 'euclidean'))
    jS = squareform(pdist(sp_data[1], 'jaccard')).mean()
    x_coord = sp_data[1]  # np.flip(dataset.train.sp_data[_][1], 1)
    intensities = sp_data[0].mean(axis=1)





    G = nx.from_numpy_array(Y)
    ##########  edge rank
    sim = nx.simrank_similarity(G)
    er = np.mean(np.array([[sim[u][v] for v in G] for u in G]), axis=1)

    ########### edge weight & edge convolution

    minLineWidth = 0.25
    edge_weight = []
    edge_conv = 0

    for u, v, d in G.edges(data=True):
        edge_weight.append(d['weight'])
        edge_conv +=d['weight']



    #######   Average Degree
    deg = []
    for dd in range(len(G.degree)):
        deg.append(G.degree[dd])
    Avg_deg = sum(deg) / len(deg)  ########## average degree of nodes calculation

    ######### betweeness centrality
    bc = nx.betweenness_centrality(G)
    bc_List = list(bc.values())

        ##########  Power law exponent

    degrees = {}
    for node in G.nodes():
        key = len([n for n in G.neighbors(node)])
        degrees[key] = degrees.get(key, 0) + 1

    max_degree = max(degrees.keys(), key=int)
    num_nodes = []
    for i in range(1, max_degree + 1):
        num_nodes.append(degrees.get(i, 0))

    fit = powerlaw.Fit(G.nodes)
    power_law_exp = fit.power_law.alpha
        #############   common neighbour
    common_neigh = []
    for i in range(len(G.nodes)):
        common_neigh.append(len(sorted(nx.common_neighbors(G, i, 10))))
    pos = dict(zip(range(len(x_coord)), x_coord.tolist()))
    rotated_pos = {node: (y, -x) for (node, (x, y)) in pos.items()}  # rotate the coords by 90 degree

    edge_list = []
    for src, dsts in enumerate(compute_edges_list(adj_matrix)[0]):
        for dst in dsts:
            edge_list.append((src, dst))
    No_of_conections = len(edge_list)


    if with_edges:
        nx.draw_networkx_nodes(G, rotated_pos, node_color=intensities, cmap=matplotlib.cm.Reds,
                               node_size=60)
        nx.draw_networkx_edges(G, rotated_pos, edge_list, alpha=0.3)

    if feat_coord:

        pass
    else:

        nx.draw_networkx_nodes(G, rotated_pos, node_color=intensities, cmap=matplotlib.cm.Reds,
                               node_size=60)
    if not with_edges:
        clr = []
        intensities = np.round(intensities)
        for i in range(len(intensities)):
            if intensities[i] == 1:
                clr.append('red')
            else:
                clr.append('white')
        nx.draw_networkx_nodes(G, rotated_pos, node_color=clr, cmap=matplotlib.cm.Reds,
                               node_size=60)
        plt.savefig('1.png', bbox_inches='tight', transparent=True)

    return No_of_conections, edge_weight, np.mean(common_neigh), Avg_deg, jS,er, bc_List, power_law_exp,edge_conv,G




def show_image(idx,dataset):
    import matplotlib.pyplot as plt2
    x, label = dataset[idx]  # x is now a torch.Tensor

    npimg = x.numpy()

    k = np.transpose(npimg, (1, 2, 0))
    import cv2
    k = cv2.resize(k, (256, 256))
    return k

def call_main(tr):  ##### tr--- training percentage(0.5,0.6,0.7,0.8,0.9)
    dn = 100
    # Taking the test dataset only for sample visualization
    use_feat_for_graph_construct = False
    tt = time.time()
    data_no_feat_knn = MNISTSuperPix("dataset\superpixels\superpixels",
                                 #split='test',
                                 split='train',
                                 use_feat_for_graph_construct=use_feat_for_graph_construct)

    data_no_feat_knn.precompute_graph_images()
    print("Time taken: {:.4f}s".format(time.time()-tt))

    use_feat_for_graph_construct = True
    tt = time.time()
    data_with_feat_knn = MNISTSuperPix("dataset\superpixels\superpixels",
                                 #split='test',
                                 split='train',
                                 use_feat_for_graph_construct=use_feat_for_graph_construct)

    data_with_feat_knn.precompute_graph_images()
    print("Time taken: {:.4f}s".format(time.time()-tt))

    #dataset = datasets.MNIST(root='PATH', train=False, download=True, transform=transforms.ToTensor())
    dataset = datasets.MNIST(root='PATH', train=True, download=True, transform=transforms.ToTensor())
    ACC,  ASR,  VS = [],  [],  []
    T = int(tr * 100)
    for i in range(T):


        x, _ = dataset[dn] # x is now a torch.Tensor


        sample = np.random.choice(len(data_no_feat_knn))
        g_sample = data_no_feat_knn[sample][0]
        print("Label: ", data_no_feat_knn[sample][1])

        label = data_no_feat_knn[sample][1]
        nx.draw(g_sample.to_networkx(), with_labels=True)




        from scipy.spatial.distance import pdist, squareform
        from pylab import rcParams

        num_samples_plot = 3
        for f_idx, idx in enumerate(np.random.choice(int(len(data_no_feat_knn)/2), num_samples_plot, replace=False)):

            def main(label):
                inp = show_image(idx,dataset)
                No_of_conections, edge_weight, common_neigh, Avg_deg, jS,er, bc_List, power_law_exp, edge_conv, G = get_features(plt.figure(),
                                                                                                   data_no_feat_knn.sp_data[
                                                                                                       idx],
                                                                                                   data_no_feat_knn.Adj_matrices[
                                                                                                       idx],
                                                                                                   data_no_feat_knn[idx][1],
                                                                                                   data_no_feat_knn.use_feat_for_graph,
                                                                                                   with_edges=False)


                featr = [No_of_conections,common_neigh, Avg_deg, jS,power_law_exp,edge_conv] +edge_weight + er.tolist()+ bc_List
                featr = np.array(featr)
                label = np.array([label])
                ####### proposed
                attack = gnn.classify(featr, label, G, inp, ACC, ASR, VS)
                if attack:
                    main(label)
                else:
                    pass




            main(label)

        dn = dn + 100
    ACC,  ASR,  VS = np.mean(ACC),  np.mean(ASR),  np.mean(VS)
    return ACC,  ASR,  VS

# call_main(0.5)